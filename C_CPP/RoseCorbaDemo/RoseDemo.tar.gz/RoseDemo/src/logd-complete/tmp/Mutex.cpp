#include "Mutex.h"

//##ModelId=3F3D7CB0033F
Mutex::Mutex()
{
    pthread_mutex_init( &mutex, NULL );
}


//##ModelId=3F3D7CB003AE
Mutex::~Mutex()
{
    pthread_mutex_destroy( &mutex );
}

//##ModelId=3F3D7CB40205
void Mutex::lock()
{
    pthread_mutex_lock( &mutex );
}

//##ModelId=3F3D7CB80247
void Mutex::unlock()
{
    pthread_mutex_unlock( &mutex );
}

//##ModelId=3F3D7CBC00C6
bool Mutex::trylock()
{
    return (pthread_mutex_trylock( &mutex ));
}

//##ModelId=3F3D7CB0035E
Mutex::Mutex(const Mutex& right)
{
    // private
}

//##ModelId=3F3D7CB003CC
Mutex& Mutex::operator=(const Mutex& right)
{
    // private
}

