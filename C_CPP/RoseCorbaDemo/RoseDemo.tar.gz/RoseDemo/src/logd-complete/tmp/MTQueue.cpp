#include "MTQueue.h"

//##ModelId=3F3D7FD90090
template <class T>
MTQueue<T>::MTQueue()
{
    // Nothing to do
}


//##ModelId=3F3D7FD900FE
template <class T>
MTQueue<T>::~MTQueue()
{
    // Nothing to do
}

//##ModelId=3F3D7FEF02B8
template <class T>
void MTQueue<T>::push(T* obj)
{
    mutex.lock();
    fifo.push_back( obj );
    mutex.unlock();
}

//##ModelId=3F3D80140026
template <class T>
T* MTQueue<T>::pop()
{
    T* retVal = NULL;
    mutex.lock();
    if ( !fifo.empty() ) {
        retVal = fifo.pop_front();
    }
    mutex.unlock();
    return retVal;
}

//##ModelId=3F3D80180253
template <class T>
bool MTQueue<T>::isEmpty()
{
    bool retVal;
    mutex.lock();
    retVal = !fifo.empty();
    mutex.unlock();
    return retVal;
}

//##ModelId=3F3D802300F0
template <class T>
void MTQueue<T>::clear()
{
    mutex.lock();
    fifo.clear();
    mutex.unlock();
}

//##ModelId=3F3D7FD900AE
template <class T>
MTQueue<T>::MTQueue(const MTQueue& right)
{
    // private
}

//##ModelId=3F3D7FD90126
template <class T>
MTQueue<T>& MTQueue<T>::operator=(const MTQueue& right)
{
    // private
}

