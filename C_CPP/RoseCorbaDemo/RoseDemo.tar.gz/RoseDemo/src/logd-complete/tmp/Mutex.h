#ifndef MUTEX_H_HEADER_INCLUDED_C0C2F6FC
#define MUTEX_H_HEADER_INCLUDED_C0C2F6FC

#include <pthread.h>

//##ModelId=3F3D618D00D3
class Mutex
{
  public:
    //##ModelId=3F3D7CB0033F
    Mutex();

    //##ModelId=3F3D7CB003AE
    virtual ~Mutex();

    //##ModelId=3F3D7CB40205
    void lock();

    //##ModelId=3F3D7CB80247
    void unlock();

    //##ModelId=3F3D7CBC00C6
    bool trylock();

  private:
    //##ModelId=3F3D7CB0035E
    Mutex(const Mutex& right);

    //##ModelId=3F3D7CB003CC
    Mutex& operator=(const Mutex& right);

    //##ModelId=3F3D7CE80250
    pthread_mutex_t mutex;

};



#endif /* MUTEX_H_HEADER_INCLUDED_C0C2F6FC */
