#ifndef THREAD_H_HEADER_INCLUDED_C0C2BFC0
#define THREAD_H_HEADER_INCLUDED_C0C2BFC0

#include <pthread.h>

//##ModelId=3F3D58930043
class Thread
{
  public:
    //##ModelId=3F3D6136036D
    virtual ~Thread();

    //##ModelId=3F3D610E004E
    void run();

    //##ModelId=3F3D724300DF
    void join();

    //##ModelId=3F3D72480208
    void cancel();

    //##ModelId=3F3D725A0146
    void detach();

  protected:
    //##ModelId=3F3D613602B9
    Thread();

    //##ModelId=3F3D611C0261
    virtual void start() = 0;

  private:
    //##ModelId=3F3D613602E1
    Thread(const Thread& right);

    //##ModelId=3F3D613603BD
    Thread& operator=(const Thread& right);

    //##ModelId=3F3D72970021
    static void* threadStart(void* arg);

    //##ModelId=3F3D61A001AD
    pthread_t threadId;

    //##ModelId=3F3D61B400CF
    pthread_attr_t threadAttributes;

};



#endif /* THREAD_H_HEADER_INCLUDED_C0C2BFC0 */
