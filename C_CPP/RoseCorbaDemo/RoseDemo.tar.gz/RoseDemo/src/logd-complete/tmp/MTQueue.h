#ifndef MTQUEUE_H_HEADER_INCLUDED_C0C24AA6
#define MTQUEUE_H_HEADER_INCLUDED_C0C24AA6
#include "Mutex.h"

#include <list>

//##ModelId=3F3D707500C6
template <class T>
class MTQueue
{
  public:
    //##ModelId=3F3D7FD90090
    MTQueue();

    //##ModelId=3F3D7FD900FE
    virtual ~MTQueue();

    //##ModelId=3F3D7FEF02B8
    void push(T* obj);

    //##ModelId=3F3D80140026
    T* pop();

    //##ModelId=3F3D80180253
    bool isEmpty();

    //##ModelId=3F3D802300F0
    void clear();

  private:
    //##ModelId=3F3D7FD900AE
    MTQueue(const MTQueue& right);

    //##ModelId=3F3D7FD90126
    MTQueue& operator=(const MTQueue& right);

    //##ModelId=3F3D7080011C
    Mutex mutex;

    //##ModelId=3F3D7F940217
    std::list<T*> fifo;

};



#endif /* MTQUEUE_H_HEADER_INCLUDED_C0C24AA6 */
