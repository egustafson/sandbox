#include "Thread.h"

//##ModelId=3F3D6136036D
Thread::~Thread()
{
}

//##ModelId=3F3D610E004E
void Thread::run()
{
    pthread_create( &threadId, &threadAttributes, Thread::threadStart, this );
}

//##ModelId=3F3D724300DF
void Thread::join()
{
    void* tmp;
    pthread_join( threadId, &tmp );
}

//##ModelId=3F3D72480208
void Thread::cancel()
{
    pthread_cancel( threadId );
}

//##ModelId=3F3D725A0146
void Thread::detach()
{
    pthread_detach( threadId );
}

//##ModelId=3F3D613602B9
Thread::Thread()
{
    pthread_attr_init( &threadAttributes );
}


//##ModelId=3F3D613602E1
Thread::Thread(const Thread& right)
{
    // private
}

//##ModelId=3F3D613603BD
Thread& Thread::operator=(const Thread& right)
{
    // private
}

//##ModelId=3F3D72970021
void* Thread::threadStart(void* arg)
{
    ((Thread*)arg)->start();
    return NULL;
}

