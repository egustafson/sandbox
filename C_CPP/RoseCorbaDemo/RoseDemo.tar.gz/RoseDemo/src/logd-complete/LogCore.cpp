#include "LogCore.h"

//##ModelId=3F3D841202BB
LogCore::LogCore()
{
    // Nothing to do
}


//##ModelId=3F3D84120329
LogCore::~LogCore()
{
    // Nothing to do, we don't own the subscribers
}

//##ModelId=3F3D83560062
void LogCore::submitLog(const std::string& msg)
{
    std::list<LogSubscriber*>::iterator itor;
    for ( itor = subscribers.begin(); itor != subscribers.end(); ++itor ) {
        (*itor)->message( msg );
    }
}

//##ModelId=3F3D836A010B
void LogCore::subscribe(LogSubscriber* sub)
{
    subscribers.push_back( sub );
}

//##ModelId=3F3D841202D9
LogCore::LogCore(const LogCore& right)
{
    // private
}

//##ModelId=3F3D84120347
LogCore& LogCore::operator=(const LogCore& right)
{
    // private
}

