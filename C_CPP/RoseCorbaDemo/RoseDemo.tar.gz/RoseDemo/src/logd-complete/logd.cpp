#include <iostream>
#include "LogCore.h"
#include "ConsoleLogSub.h"
#include "FileLogSubscriber.h"

using namespace std;

int main() {
    
    LogCore logger;
    ConsoleLogSub csub;
    FileLogSubscriber fsub("logfile.txt");

    logger.submitLog( "1: Hello, world." );
    logger.subscribe( &csub );
    logger.subscribe( &fsub );
    logger.submitLog( "2: Hello, world." );

    cout<<"Stub."<<endl;

    return 0;
}
