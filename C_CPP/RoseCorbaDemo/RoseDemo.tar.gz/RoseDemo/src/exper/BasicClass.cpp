#include <iostream>

#include "BasicClass.h"

//##ModelId=3F394B3D01F6
Exper::BasicClass::BasicClass()
    : numAccesses(0)
{
}

//##ModelId=3F394B3D02E7
Exper::BasicClass::BasicClass(const BasicClass& right)
{
    // private
}

//##ModelId=3F394B3D0355
Exper::BasicClass::~BasicClass()
{
}

//##ModelId=3F394B3D039B
Exper::BasicClass& Exper::BasicClass::operator=(const BasicClass& right)
{
    // private
    return *this;
}

//##ModelId=3F391762032E
int Exper::BasicClass::getNumAccesses()
{
    std::cerr<<"getNumAccesses() invoked."<<std::endl;
    numAccesses++;
    return numAccesses;
}

//##ModelId=3F39176A0163
void Exper::BasicClass::clearNumAccesses()
{
    std::cerr<<"clearNumAccesses() invoked."<<std::endl;
    numAccesses = 0;
}

//##ModelId=3F39177401E0
std::string Exper::BasicClass::getGreeting()
{
    std::cerr<<"getGreeting() invoked."<<std::endl;
    return "Hello";
}

