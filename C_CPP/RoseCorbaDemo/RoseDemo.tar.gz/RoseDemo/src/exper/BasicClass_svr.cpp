#include "BasicClass_svr.h"

//##ModelId=3F391E73022B
Exper::BasicClass_svr::BasicClass_svr()
{
    // private
}


//##ModelId=3F391E73023F
Exper::BasicClass_svr::BasicClass_svr(const BasicClass_svr& right)
{
    // private
}

//##ModelId=3F391E7302A3
Exper::BasicClass_svr::~BasicClass_svr()
{
    // Do nothing, we didn't allocate basicClass
}

//##ModelId=3F391E7302CB
Exper::BasicClass_svr& Exper::BasicClass_svr::operator=(const BasicClass_svr& right)
{
    // private
}

//##ModelId=3F3953F002FD
Exper::BasicClass_svr::BasicClass_svr(BasicClass* obj)
{
    basicClass = obj;
}

//##ModelId=3F3955EF0095
CORBA::Long Exper::BasicClass_svr::getNumAccesses() throw(CORBA::SystemException)
{
    return basicClass->getNumAccesses();
}

//##ModelId=3F3955FF0160
void Exper::BasicClass_svr::clearNumAccesses() throw(CORBA::SystemException)
{
    basicClass->clearNumAccesses();
}

//##ModelId=3F395607032E
char* Exper::BasicClass_svr::getGreeting() throw(CORBA::SystemException)
{
    CORBA::String_var retString( basicClass->getGreeting().c_str() );
    return retString._retn();
}

