#include <iostream>

#include "BasicClass_svr.h"
#include "BasicClass.h"

using namespace std;

int main(int argc, char* argv[]) {
    cerr<<"Running"<<endl;

    Exper::BasicClass myObj;
//     cerr<<"BasicClass.getGreeting(): "<<myObj.getGreeting()<<endl;


    try { 
        // init ORB
        CORBA::ORB_var orb = CORBA::ORB_init(argc, argv);

        // Get reference to Root POA
        CORBA::Object_var obj = orb->resolve_initial_references("RootPOA");
        PortableServer::POA_var poa = PortableServer::POA::_narrow(obj);

        // Activate POA manager
        PortableServer::POAManager_var mgr = poa->the_POAManager();
        mgr->activate();

        // Create an object
        Exper::BasicClass_svr mySvr( &myObj );
        

        // Write the stringified reference to stdout
        BasicClass_if_var bc = mySvr._this();
        CORBA::String_var str = orb->object_to_string(bc);
        cout<<str<<endl;

        {
            // Use myself locally

            cerr<<"BasicClass_if->getNumAccesses() = "<<bc->getNumAccesses()<<endl;
            cerr<<"BasicClass_if->getNumAccesses() = "<<bc->getNumAccesses()<<endl;
            cerr<<"BasicClass_if->getGreeting()    = "<<(const char*)bc->getGreeting()<<endl;

        }

        // Act as a servant
        cerr<<"Starting ORB."<<endl;
        orb->run();
    } 
    catch (const CORBA::Exception&) {
        cerr<<"Uncought CORBA exception"<<endl;
        return 1;
    }
    cerr<<"Finished"<<endl;
    return 0;
}
