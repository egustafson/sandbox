#ifndef COLOR_E_H_HEADER_INCLUDED_C0C591B3
#define COLOR_E_H_HEADER_INCLUDED_C0C591B3

namespace Exper {

//##ModelId=3F3A5F020134
enum Color_e { Black, White, Red, Orange, Yellow, Green, Blue };

} // namespace Exper



#endif /* COLOR_E_H_HEADER_INCLUDED_C0C591B3 */
