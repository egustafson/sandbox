#include <iostream>

#include "BasicIDL_ifC.h"

using namespace std;

int main(int argc, char* argv[]) {

    try {

        if ( argc != 2 ) {
            cerr<<"Usage: client IOR_string"<<endl;
            throw 0;
        }

        // Initialize the ORB
        CORBA::ORB_var orb = CORBA::ORB_init(argc, argv);

        // Destringify argv[1] - the IOR
        CORBA::Object_var obj = orb->string_to_object(argv[1]);
        if ( CORBA::is_nil(obj) ) {
            cerr<<"Nil BasicClass_if reference."<<endl;
            throw 0;
        }

        // Narrow the reference
        BasicClass_if_var bc = BasicClass_if::_narrow(obj);
        if ( CORBA::is_nil(bc) ) {
            cerr<<"Argument is not a BasicClass_if reference"<<endl;
            throw 0;
        }

        // Tell the object to shutdown
        bc->shutdown();

        cout<<"Shutdown message sent."<<endl;

    } catch (const CORBA::Exception&) {
        cerr<<"Uncought CORBA exception"<<endl;
        return 1;
    } catch (...) {
        return 1;
    } 
    return 0;
}
