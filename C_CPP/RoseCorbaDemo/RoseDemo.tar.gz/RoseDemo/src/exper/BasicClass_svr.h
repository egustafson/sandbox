#ifndef BASICCLASS_SVR_H_HEADER_INCLUDED_C0C686AD
#define BASICCLASS_SVR_H_HEADER_INCLUDED_C0C686AD
#include "BasicClass.h"

#include "BasicIDL_ifS.h"

namespace Exper {

//##ModelId=3F391D5803BF
class BasicClass_svr : public POA_BasicClass_if
{
  public:
    //##ModelId=3F391E7302A3
    virtual ~BasicClass_svr();

    //##ModelId=3F3953F002FD
    BasicClass_svr(BasicClass* obj);

    //##ModelId=3F3955EF0095
    virtual CORBA::Long getNumAccesses() throw(CORBA::SystemException);

    //##ModelId=3F3955FF0160
    virtual void clearNumAccesses() throw(CORBA::SystemException);
  
    //##ModelId=3F395607032E
    virtual char* getGreeting() throw(CORBA::SystemException);

  protected:
    //##ModelId=3F391DE20042
    BasicClass* basicClass;

  private:
    //##ModelId=3F391E73022B
    BasicClass_svr();

    //##ModelId=3F391E73023F
    BasicClass_svr(const BasicClass_svr& right);

    //##ModelId=3F391E7302CB
    BasicClass_svr& operator=(const BasicClass_svr& right);

};

} // namespace Exper



#endif /* BASICCLASS_SVR_H_HEADER_INCLUDED_C0C686AD */
