#ifndef BASICCLASS_H_HEADER_INCLUDED_C0C6E104
#define BASICCLASS_H_HEADER_INCLUDED_C0C6E104

#include <string>

namespace Exper {

//##ModelId=3F39174B0082
class BasicClass
{
  public:
    //##ModelId=3F394B3D01F6
    BasicClass();

    //##ModelId=3F394B3D0355
    virtual ~BasicClass();

    //##ModelId=3F391762032E
    int getNumAccesses();

    //##ModelId=3F39176A0163
    void clearNumAccesses();

    //##ModelId=3F39177401E0
    std::string getGreeting();

  protected:
    //##ModelId=3F3917540067
    int numAccesses;

  private:
    //##ModelId=3F394B3D02E7
    BasicClass(const BasicClass& right);

    //##ModelId=3F394B3D039B
    BasicClass& operator=(const BasicClass& right);
};

} // namespace Exper



#endif /* BASICCLASS_H_HEADER_INCLUDED_C0C6E104 */
