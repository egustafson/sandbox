#ifndef CONSOLELOGSUB_H_HEADER_INCLUDED_C0C275CD
#define CONSOLELOGSUB_H_HEADER_INCLUDED_C0C275CD
#include "LogSubscriber.h"

//##ModelId=3F3D84900104
class ConsoleLogSub : public LogSubscriber
{
  public:
    //##ModelId=3F3D895F02F8
    ConsoleLogSub();

    //##ModelId=3F3D895F0316
    ConsoleLogSub(const ConsoleLogSub& right);

    //##ModelId=3F3D895F0371
    virtual ~ConsoleLogSub();

    //##ModelId=3F3D895F0399
    ConsoleLogSub& operator=(const ConsoleLogSub& right);

    //##ModelId=3F3D86B60187
    virtual void message(const std::string& msg);

};



#endif /* CONSOLELOGSUB_H_HEADER_INCLUDED_C0C275CD */
