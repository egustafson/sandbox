#ifndef LOGCORE_IMPL_H_HEADER_INCLUDED_C0BE9918
#define LOGCORE_IMPL_H_HEADER_INCLUDED_C0BE9918

// IDL Generated Skeleton
#include "Logging_ifS.h"

class LogCore;

//##ModelId=3F417C6803BF
class LogCore_impl : public POA_LogCore_if
{
  public:

    //##ModelId=3F417DB10250
    virtual ~LogCore_impl();

    //##ModelId=3F417CB601CD
    virtual void submitLog(const char* msg) throw(CORBA::SystemException);

    //##ModelId=3F417CB900D7
    virtual void subscribe(LogSubscriber_if_ptr sub) throw(CORBA::SystemException);

    //##ModelId=3F417FC202AB
    LogCore_impl(LogCore* loggingCore);

  private:

    //##ModelId=3F417DB101CE
    LogCore_impl();

    //##ModelId=3F417DB101EC
    LogCore_impl(const LogCore_impl& right);

    //##ModelId=3F417DB10278
    LogCore_impl& operator=(const LogCore_impl& right);

    //##ModelId=3F417D6B0169
    LogCore *logCore;

};



#endif /* LOGCORE_IMPL_H_HEADER_INCLUDED_C0BE9918 */
