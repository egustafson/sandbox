#include "FileLogSubscriber.h"

//##ModelId=3F41548000F8
FileLogSubscriber::~FileLogSubscriber()
{
    // nothing to do
}

//##ModelId=3F4154B002EC
FileLogSubscriber::FileLogSubscriber(const std::string& fName)
    : logFile( fName.c_str() )
{
}

//##ModelId=3F41548000B2
FileLogSubscriber::FileLogSubscriber(const FileLogSubscriber& right)
{
    // private, nothing to do
}




//##ModelId=3F4154800116
FileLogSubscriber& FileLogSubscriber::operator=(const FileLogSubscriber& right)
{
    // private, nothing to do
}

//##ModelId=3F4157BA024B
void FileLogSubscriber::message(const std::string& msg)
{
    logFile<<msg<<std::endl;
}



//##ModelId=3F4154800094
FileLogSubscriber::FileLogSubscriber()
{
}

