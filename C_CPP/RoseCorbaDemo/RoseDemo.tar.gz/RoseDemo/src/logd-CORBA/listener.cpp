#include <iostream>
#include <fstream>
#include "LogSubscriber_impl.h"

using namespace std;

CORBA::ORB_var orb;

int main(int argc, char* argv[]) {

    if ( argc != 2 ) {
        cerr<<"Usage: listener IOR_string"<<endl;
        return 1;
    }

    try {
        // init ORB
        orb = CORBA::ORB_init(argc, argv);

        // Destringify argv[1] - the IOR
        CORBA::Object_var logCoreObjRef = orb->string_to_object(argv[1]);
        if ( CORBA::is_nil(logCoreObjRef) ) {
            cerr<<"Nill LogCore_if reference."<<endl;
            return 1;
        }

        // Narrow the reference
        LogCore_if_var lc = LogCore_if::_narrow(logCoreObjRef);
        if ( CORBA::is_nil(lc) ) {
            cerr<<"Argument is not a LogCore_if reference"<<endl;
            return 1;
        }

        // Get reference to Root POA
        CORBA::Object_var poaObjRef = orb->resolve_initial_references("RootPOA");
        PortableServer::POA_var poa = PortableServer::POA::_narrow(poaObjRef);

        // Activate POA manager
        PortableServer::POAManager_var mgr = poa->the_POAManager();
        mgr->activate();

        // Create an object
        LogSubscriber_impl logSub;

        // Register ourselves with the LogCore
        LogSubscriber_if_var ls = logSub._this();
        lc->subscribe( ls );

        CORBA::String_var str = orb->object_to_string(ls);
        ofstream iorFile( "list.ior" );
        cerr<<str<<endl;
        iorFile<<str<<endl;

        ls->message( "Local Message" );

        // Act as a servant - (wait for callbacks)
        cerr<<"Starting ORB."<<endl;
        orb->run();

    } 
    catch (const CORBA::Exception&) {
        cerr<<"Uncought CORBA exception"<<endl;
        return 1;
    }
    return 0;
}
