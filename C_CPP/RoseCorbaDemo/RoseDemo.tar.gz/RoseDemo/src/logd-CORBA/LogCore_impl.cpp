#include "LogCore_impl.h"
#include "LogCore.h"
#include "CORBALogSub.h"

#include <iostream>

//##ModelId=3F417DB101CE
LogCore_impl::LogCore_impl()
{
    // Private
}

//##ModelId=3F417DB101EC
LogCore_impl::LogCore_impl(const LogCore_impl& right)
{
    // Private
}

//##ModelId=3F417DB10250
LogCore_impl::~LogCore_impl()
{
    // No action Necessary
}

//##ModelId=3F417DB10278
LogCore_impl& LogCore_impl::operator=(const LogCore_impl& right)
{
    // Private
}

//##ModelId=3F417CB601CD
void LogCore_impl::submitLog(const char* msg) throw(CORBA::SystemException)
{
    logCore->submitLog( std::string( msg ) );
}

//##ModelId=3F417CB900D7
void LogCore_impl::subscribe(LogSubscriber_if_ptr sub) throw(CORBA::SystemException)
{
    // Note - memory leak here
    LogSubscriber* logSub = new CORBALogSub( sub );
    logCore->subscribe( logSub );
}

//##ModelId=3F417FC202AB
LogCore_impl::LogCore_impl(LogCore* loggingCore)
    : logCore( loggingCore )
{
}

