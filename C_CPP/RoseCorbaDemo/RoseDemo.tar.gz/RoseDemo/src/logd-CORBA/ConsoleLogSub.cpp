#include "ConsoleLogSub.h"

#include <iostream>

//##ModelId=3F3D895F02F8
ConsoleLogSub::ConsoleLogSub()
{
    // nothing to do
}


//##ModelId=3F3D895F0316
ConsoleLogSub::ConsoleLogSub(const ConsoleLogSub& right)
{
    // nothing to do
}

//##ModelId=3F3D895F0371
ConsoleLogSub::~ConsoleLogSub()
{
    // nothing to do
}

//##ModelId=3F3D895F0399
ConsoleLogSub& ConsoleLogSub::operator=(const ConsoleLogSub& right)
{
    // nothing to do
}

//##ModelId=3F3D86B60187
void ConsoleLogSub::message(const std::string& msg)
{
    std::cerr<<msg<<std::endl;
}

