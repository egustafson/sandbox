#include <iostream>
#include <string>
#include "Logging_ifC.h"

using namespace std;

int main(int argc, char* argv[]) {

    if ( argc != 2 ) {
        cerr<<"Usage: sendLog IOR_string"<<endl;
        throw 0;
    }

    try {
        // Initialize the ORB
        CORBA::ORB_var orb = CORBA::ORB_init(argc, argv);

        // Destringify argv[1] - the IOR
        CORBA::Object_var obj = orb->string_to_object(argv[1]);
        if ( CORBA::is_nil(obj) ) {
            cerr<<"Nil LogCore_if reference."<<endl;
            throw 0;
        }

        // Narrow the reference
        LogCore_if_var lc = LogCore_if::_narrow(obj);
        if ( CORBA::is_nil(lc) ) {
            cerr<<"Argument is not a Logcore_if reference"<<endl;
            throw 0;
        }

        // Collect the log message from stdin
        std::string input;
        getline( cin, input );

        // Send the log message
        CORBA::String_var msg( input.c_str() );
        lc->submitLog( input.c_str() );
        
    } catch (const CORBA::Exception&) {
        cerr<<"Uncought CORBA exception"<<endl;
        return 1;
    }
    return 0;
}
