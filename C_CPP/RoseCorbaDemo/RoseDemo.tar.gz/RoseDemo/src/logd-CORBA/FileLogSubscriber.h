#ifndef FILELOGSUBSCRIBER_H_HEADER_INCLUDED_C0BE9204
#define FILELOGSUBSCRIBER_H_HEADER_INCLUDED_C0BE9204
#include "LogSubscriber.h"

#include <fstream>

//##ModelId=3F41545E006D
class FileLogSubscriber : public LogSubscriber
{
  public:
    //##ModelId=3F41548000F8
    virtual ~FileLogSubscriber();

    //##ModelId=3F4154B002EC
    FileLogSubscriber(const std::string& fName);

    //##ModelId=3F4157BA024B
    virtual void message(const std::string& msg);





  private:
    //##ModelId=3F41548000B2
    FileLogSubscriber(const FileLogSubscriber& right);


    //##ModelId=3F4154800116
    FileLogSubscriber& operator=(const FileLogSubscriber& right);
    //##ModelId=3F4154800094
    FileLogSubscriber();

    //##ModelId=3F41554C039B
    std::ofstream logFile;



};



#endif /* FILELOGSUBSCRIBER_H_HEADER_INCLUDED_C0BE9204 */
