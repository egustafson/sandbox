#ifndef CORBALOGSUB_H_HEADER_INCLUDED_C0BE4A99
#define CORBALOGSUB_H_HEADER_INCLUDED_C0BE4A99

#include "Logging_ifC.h"
#include "LogSubscriber.h"

//##ModelId=3F4180AC009E
class CORBALogSub : public LogSubscriber
{
  public:
    //##ModelId=3F41812500E8
    virtual ~CORBALogSub();

    //##ModelId=3F41816D013C
    CORBALogSub(LogSubscriber_if_ptr subProxy);

    //##ModelId=3F41815B00DC
    virtual void message(const std::string& msg);

  protected:
    //##ModelId=3F418125003E
    CORBALogSub();

  private:
    //##ModelId=3F418125005C
    CORBALogSub(const CORBALogSub& right);

    //##ModelId=3F4181250124
    CORBALogSub& operator=(const CORBALogSub& right);

    //##ModelId=3F4181280237
    LogSubscriber_if_var cSubProxy;

};



#endif /* CORBALOGSUB_H_HEADER_INCLUDED_C0BE4A99 */
