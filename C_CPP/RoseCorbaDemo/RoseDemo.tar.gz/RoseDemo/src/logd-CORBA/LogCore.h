#ifndef LOGCORE_H_HEADER_INCLUDED_C0C27C5D
#define LOGCORE_H_HEADER_INCLUDED_C0C27C5D

#include <list>
#include <string>

#include "LogSubscriber.h"

//##ModelId=3F3D586F029A
//##Documentation
//## 
class LogCore
{
  public:
    //##ModelId=3F3D841202BB
    LogCore();

    //##ModelId=3F3D84120329
    virtual ~LogCore();

    //##ModelId=3F3D83560062
    void submitLog(const std::string& msg);

    //##ModelId=3F3D836A010B
    void subscribe(LogSubscriber* sub);

  private:
    //##ModelId=3F3D841202D9
    LogCore(const LogCore& right);

    //##ModelId=3F3D84120347
    LogCore& operator=(const LogCore& right);

    //##ModelId=3F3D85E10158
    std::list<LogSubscriber*> subscribers;

};



#endif /* LOGCORE_H_HEADER_INCLUDED_C0C27C5D */
