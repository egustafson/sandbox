#include "LogSubscriber.h"

//##ModelId=3F3D83DE02A2
LogSubscriber::~LogSubscriber()
{
    // Nothing to do
}

//##ModelId=3F3D83DE023E
LogSubscriber::LogSubscriber()
{
    // Nothing to do
}


//##ModelId=3F3D83DE0252
LogSubscriber::LogSubscriber(const LogSubscriber& right)
{
    // private
}

//##ModelId=3F3D83DE02C0
LogSubscriber& LogSubscriber::operator=(const LogSubscriber& right)
{
    // private
}

