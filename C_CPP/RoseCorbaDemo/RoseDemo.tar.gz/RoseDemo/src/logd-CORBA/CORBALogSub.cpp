#include "CORBALogSub.h"

extern CORBA::ORB_var orb;

//##ModelId=3F41812500E8
CORBALogSub::~CORBALogSub()
{
    // nothing to do
}

//##ModelId=3F41816D013C
CORBALogSub::CORBALogSub(LogSubscriber_if_ptr subProxy)
{
    cSubProxy = LogSubscriber_if::_duplicate(subProxy);
}

//##ModelId=3F41815B00DC
void CORBALogSub::message(const std::string& msg)
{
    cSubProxy->message( CORBA::String_var( msg.c_str() ) );
}

//##ModelId=3F418125003E
CORBALogSub::CORBALogSub()
{
    // private
}


//##ModelId=3F418125005C
CORBALogSub::CORBALogSub(const CORBALogSub& right)
{
    // private
}

//##ModelId=3F4181250124
CORBALogSub& CORBALogSub::operator=(const CORBALogSub& right)
{
    // private
}

