#ifndef MAIN_H_HEADER_INCLUDED_C0BE82E4
#define MAIN_H_HEADER_INCLUDED_C0BE82E4

//##ModelId=3F41602A0188
class Main
{
  public:
    //##ModelId=3F41603802BF
    friend int main(int argc, char** argv);
    //##ModelId=3F4160E70126
    Main operator+(int x);


};



#endif /* MAIN_H_HEADER_INCLUDED_C0BE82E4 */
