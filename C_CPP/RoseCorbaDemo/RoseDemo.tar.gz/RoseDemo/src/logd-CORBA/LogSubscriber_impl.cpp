#include "LogSubscriber_impl.h"

#include <iostream>

//##ModelId=3F417E5602BB
LogSubscriber_impl::LogSubscriber_impl()
{
}


//##ModelId=3F417E560315
LogSubscriber_impl::~LogSubscriber_impl()
{
    // nothing to do
}

//##ModelId=3F417E9C02E4
void LogSubscriber_impl::message(const char* msg) throw(CORBA::SystemException)
{
    std::cout<<msg<<std::endl;
}

//##ModelId=3F417E5602CF
LogSubscriber_impl::LogSubscriber_impl(const LogSubscriber_impl& right)
{
    // private
}

//##ModelId=3F417E56033D
LogSubscriber_impl& LogSubscriber_impl::operator=(const LogSubscriber_impl& right)
{
    // private
}

