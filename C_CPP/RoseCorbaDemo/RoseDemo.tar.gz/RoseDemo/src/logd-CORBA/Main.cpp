#include "Main.h"

//##ModelId=3F41603802BF
int main(int argc, char** argv)
{
}

//##ModelId=3F4160E70126
Main Main::operator+(int x)
{
}

