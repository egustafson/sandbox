#include <iostream>
#include "LogCore.h"
#include "ConsoleLogSub.h"
#include "FileLogSubscriber.h"

#include "LogCore_impl.h"

using namespace std;

CORBA::ORB_var orb;

int main(int argc, char* argv[]) {
    
    LogCore logger;
    ConsoleLogSub csub;
    FileLogSubscriber fsub("logfile.txt");

    logger.submitLog( "1: Hello, world." );
    logger.subscribe( &csub );
    logger.subscribe( &fsub );
    logger.submitLog( "2: Hello, world." );

    try { 
        // init ORB
        orb = CORBA::ORB_init(argc, argv);

        // Get reference to Root POA
        CORBA::Object_var obj = orb->resolve_initial_references("RootPOA");
        PortableServer::POA_var poa = PortableServer::POA::_narrow(obj);

        // Activate POA manager
        PortableServer::POAManager_var mgr = poa->the_POAManager();
        mgr->activate();

        // Create an object
        LogCore_impl logCoreServant( &logger );

        // Write the stringified reference to stdout
        LogCore_if_var lc = logCoreServant._this();
        CORBA::String_var str = orb->object_to_string(lc);
        cout<<str<<endl;

        // Act as a servant
        cerr<<"Starting ORB."<<endl;
        orb->run();

    } 
    catch (const CORBA::Exception&) {
        cerr<<"Uncought CORBA exception"<<endl;
        return 1;
    }
    return 0;
}
