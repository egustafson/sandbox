#ifndef LOGSUBSCRIBER_IMPL_H_HEADER_INCLUDED_C0BE3F44
#define LOGSUBSCRIBER_IMPL_H_HEADER_INCLUDED_C0BE3F44

#include "Logging_ifS.h"

//##ModelId=3F417E3B01EA
class LogSubscriber_impl : public POA_LogSubscriber_if
{
  public:
    //##ModelId=3F417E5602BB
    LogSubscriber_impl();

    //##ModelId=3F417E560315
    virtual ~LogSubscriber_impl();

    //##ModelId=3F417E9C02E4
    virtual void message(const char* msg) throw(CORBA::SystemException);

  private:
    //##ModelId=3F417E5602CF
    LogSubscriber_impl(const LogSubscriber_impl& right);

    //##ModelId=3F417E56033D
    LogSubscriber_impl& operator=(const LogSubscriber_impl& right);

};



#endif /* LOGSUBSCRIBER_IMPL_H_HEADER_INCLUDED_C0BE3F44 */
