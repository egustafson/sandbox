#ifndef LOGSUBSCRIBER_H_HEADER_INCLUDED_C0C21A3A
#define LOGSUBSCRIBER_H_HEADER_INCLUDED_C0C21A3A

#include <string>

//##ModelId=3F3D587A0264
class LogSubscriber
{
  public:
    //##ModelId=3F3D83DE02A2
    virtual ~LogSubscriber();

    //##ModelId=3F3D83A903E6
    virtual void message(const std::string& msg) = 0;

  protected:
    //##ModelId=3F3D83DE023E
    LogSubscriber();

  private:
    //##ModelId=3F3D83DE0252
    LogSubscriber(const LogSubscriber& right);

    //##ModelId=3F3D83DE02C0
    LogSubscriber& operator=(const LogSubscriber& right);

};



#endif /* LOGSUBSCRIBER_H_HEADER_INCLUDED_C0C21A3A */
